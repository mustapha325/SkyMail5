package com.example.skymail.Interface;

import android.view.View;

public interface RecyclerItemClick {
    public void OnItemClick(View v, int position);
}
