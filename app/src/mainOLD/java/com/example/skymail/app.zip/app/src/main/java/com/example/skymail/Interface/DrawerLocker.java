package com.example.skymail.Interface;

import android.view.MenuItem;

public interface DrawerLocker {
    public void enableDisableDrawer(int mode,boolean mode2);


}
