package com.example.skymail.CloudMessaging;

public class MyResponse {
    public int success;

}
