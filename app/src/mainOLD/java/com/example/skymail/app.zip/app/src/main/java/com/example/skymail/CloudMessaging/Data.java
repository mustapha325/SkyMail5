package com.example.skymail.CloudMessaging;

public class Data {
    private String Id;

    public Data(String id) {
        Id =id;
    }

    public Data() {
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

}
