package com.example.skymail;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.FileProvider;

import com.example.skymail.CloudMessaging.APIService;
import com.example.skymail.CloudMessaging.Client;
import com.example.skymail.CloudMessaging.Data;
import com.example.skymail.CloudMessaging.MyResponse;
import com.example.skymail.CloudMessaging.NotificationSender;
import com.example.skymail.Data.Contacts;
import com.example.skymail.Data.ImageCompression;
import com.example.skymail.Data.Messages;
import com.example.skymail.Data.Notifications;
import com.example.skymail.Data.UploadImages;
import com.example.skymail.Data.Users;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.skymail.Attachment.showNotification;
import static com.example.skymail.Data.io.access;
import static com.example.skymail.Data.io.getRandomNumberUsingNextInt;


public class Message extends AppCompatActivity {

    private static final int LAUNCH_SECOND_ACTIVITY = 1 ;
    private static final int TAKE_PICTURE = 9;
    EditText subject, object1, message;
    TextView from,id;
    String ID;
    String targetID;
    String email;
    FirebaseDatabase messagedatabase;
    FirebaseAuth fAuth;
    Toolbar toolbar;
    public File photoFile;
    private static String imageFileName;
    private String realPath;
    private static Uri UriImage,UriSave;
    DatabaseReference DraftRreference;
    public String userID;
    private String EmailFromContactInformation;
    private static String userFULLNAME,object,subject1,message1,url,to1,messageid;
    Boolean pass=true;
    ImageButton Attachment;
    DatabaseReference userdatabase;
    public static String result;
    Query Query;
    AutoCompleteTextView to;
    public List<Messages> automessageslist;
    FirebaseUser fuser;


    static OnProgressListener<UploadTask.TaskSnapshot> o;
    static UploadTask uploadTask;
    private APIService apiService;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        fAuth = FirebaseAuth.getInstance();
        apiService = Client.getClient("https://fcm.googleapis.com/").create(APIService.class);
        userdatabase = FirebaseDatabase.getInstance().getReference();
        Bundle bundle = getIntent().getExtras();
        automessageslist = (List<Messages>) bundle.getSerializable( "autolist" );

        setContentView( R.layout.activity_message );
        Users user=access(this);
        Attachment = (ImageButton) findViewById(R.id.btn_Attachment);
        //attachment button listener
        Attachment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Bloqui message ila attachement mazal ma ykamal upload
                pass=false;
                startActivityForResult(new Intent(Message.this ,Attachment.class),LAUNCH_SECOND_ACTIVITY);
            }
        });
        Intent intent = getIntent();
        from = findViewById( R.id.From );
        fuser=fAuth.getCurrentUser();
        userID = user.getUserID();
        userFULLNAME = user.getFullname();
        messageid = intent.getStringExtra( "message_id" );
        EmailFromContactInformation = user.getEmail();

        to = findViewById( R.id.To );
        object1 = findViewById( R.id.Object1 );
        subject = findViewById( R.id.Subject );
        message = findViewById( R.id.messageText );
        toolbar = findViewById( R.id.MessageActivityToolbar );
        messagedatabase = FirebaseDatabase.getInstance();
        email = EmailFromContactInformation;
        ID = userID;
        from.setText( email );
        //8

        to.setText( EmailFromContactInformation );

        setSupportActionBar( toolbar );
        getSupportActionBar().setTitle( R.string.Message_actionbar_title );
        getSupportActionBar().setDisplayHomeAsUpEnabled( true );
        getSupportActionBar().setHomeAsUpIndicator( R.drawable.x );


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate( R.menu.items, menu );
        return super.onCreateOptionsMenu( menu );
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.sendAction:
                if(pass){

                    sendmessage();
                    contact();
                    finish();

                }else{
                    Toast.makeText(Message.this, R.string.toast_not_sent, Toast.LENGTH_SHORT).show();
                }
                return true;
            case android.R.id.home:
                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference( "DraftMessages" );
                messageid = databaseReference.push().getKey();
                databaseReference.child( messageid ).child( "messageText" ).setValue( message.getText().toString().trim() );
                databaseReference.child( messageid ).child( "to" ).setValue( to.getText().toString().trim() );
                databaseReference.child( messageid ).child( "subject" ).setValue( subject.getText().toString().trim() );
                databaseReference.child( messageid ).child( "object" ).setValue( object1.getText().toString().trim() );
                if (!to.getText().toString().isEmpty() && (!object1.getText().toString().isEmpty() || !message.getText().toString().isEmpty() || !subject.getText().toString().isEmpty())){
                    DraftMessage();
                    finish();
                }else if (to.getText().toString().isEmpty()){
                    finish();
                }else{
                    finish();
                }


                return true;


        }

        return super.onOptionsItemSelected( item );
    }

    private void CompressImage(String path){
        ImageCompression ic = new ImageCompression(getApplicationContext());
        ic.compressImage(path,getFileName(UriSave));
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK && requestCode==TAKE_PICTURE) {
            CompressImage(realPath);
            Uploadfile(UriSave, getFileName(UriSave));
            //tran.startTransitionDialog();
            //StoreProfilePic(UriSave);
        }

        if (requestCode == LAUNCH_SECOND_ACTIVITY) {
            if(resultCode == Activity.RESULT_OK) {
                String uri = data.getStringExtra("Uri");
                String filename = data.getStringExtra("returned");
                String size = data.getStringExtra("size");
                //5mb ta3 pièce joint
                if ((Integer.parseInt(size) < (5 * 1000000))) {
                    Uri urim = Uri.parse(uri);
                    Uploadfile(urim, filename);
                }
                else showDialog(Message.this,getString(R.string.size_dialog_title),getString(R.string.size_dialog_message));
            }
            if (resultCode == Activity.RESULT_CANCELED) {
                Toast.makeText(this, "Canceled", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void showDialog(Context ctx, String titre, String message){
        AlertDialog a=new AlertDialog.Builder(ctx)
                .setTitle(titre)
                .setMessage(message)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
        a.show();
    }
    /*public void getRecieverInfo(){
        DatabaseReference user = FirebaseDatabase.getInstance().getReference("users");
        Query query = user.orderByChild( "email" ).equalTo( to.getText().toString().trim() );
        query.addValueEventListener( new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot u : dataSnapshot.getChildren()){
                    Users user = u.getValue(Users.class);
                    assert user != null;
                    store2("email:"+user.getEmail()+";"+"nom:"+user.getFullname()+";"+"id:"+user.getUserID()+";"+"date:"+user.getBirthdate()+";"+"gender:"+user.getGender()+";"+"pass:"+user.getPassword()+";",Message.this);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        } );
    }*/


    public void DraftMessage() {

        DraftRreference = FirebaseDatabase.getInstance().getReference( "DraftMessages" );
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference profilepicture = database.getReference( "ProfilePicture" ).child( userID );
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            profilepicture.addValueEventListener( new ValueEventListener() {
                String userID = ID;
                String messageID = DraftRreference.push().getKey();
                String From = from.getText().toString().trim();
                String To = to.getText().toString().trim();
                String Object = object1.getText().toString().trim();
                String Subject = subject.getText().toString().trim();
                String Message = message.getText().toString().trim();
                String userFullname = userFULLNAME;
                String ProfilePictureUri;
                Date date = new Date();
                @SuppressLint("SimpleDateFormat")
                SimpleDateFormat DayOfweek = new SimpleDateFormat("EEEE");
                @SuppressLint("SimpleDateFormat")
                SimpleDateFormat DayNumber = new SimpleDateFormat("FF");
                String day = DayNumber.format( date )+" "+DayOfweek.format( date )+".";
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot image : dataSnapshot.getChildren()) {
                        UploadImages ProfilePic = image.getValue( UploadImages.class );
                        assert ProfilePic != null;
                        ProfilePictureUri = ProfilePic.getmImageUrl();
                    }

                    Messages message = new Messages( userID, messageID, From, To, Subject, Object, Message, ProfilePictureUri,userFullname ,result,day,null);
                    assert messageID != null;
                    DraftRreference.child( messageID ).setValue( message );
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            } );
        }
    }



    public void sendmessage(){
        final DatabaseReference root,root2,root3;
        root = messagedatabase.getReference("InboxMessages");
        root2 =messagedatabase.getReference("SendedMessages");
        root3 = messagedatabase.getReference("Reply");
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference profilepicture = database.getReference("ProfilePicture");

        Query query1 = profilepicture.child( userID );

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            query1.addValueEventListener( new ValueEventListener() {
                String userID = fuser.getUid();
                String messageID = root.push().getKey();
                String From = from.getText().toString().trim();
                String To = to.getText().toString().trim();
                String Object = object1.getText().toString().trim();
                String Subject = subject.getText().toString().trim();
                String Messagetext = message.getText().toString().trim();
                String Reply_Message_Id = root.push().getKey();

                String ProfilePictureUri;
                Long tsLong = System.currentTimeMillis()/1000;
                String day = tsLong.toString();
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for(DataSnapshot image :dataSnapshot.getChildren()){
                        UploadImages ProfilePic = image.getValue(UploadImages.class);
                        assert ProfilePic != null;
                        ProfilePictureUri = ProfilePic.getmImageUrl();
                        Messages message = new Messages(userID,messageID,From,To,Subject,Object,Messagetext,ProfilePictureUri,userFULLNAME,result,day,Reply_Message_Id);
                        assert messageID != null;
                        root.child(messageID).setValue(message);
                        root2.child( messageID ).setValue( message );
                        root3.child( messageID ).child( "reply" ).child( Reply_Message_Id ).setValue(message);
                        getTargetId( to.getText().toString().trim(),message );
                        Notifications nt = new Notifications(message.getMessageText(),message.getMessagID(),
                                message.getSubject(),message.getFrom(),message.getSenderFullName(),
                                message.getTo(),message.getSenderProfilePicture(),message.getFileurl()
                                ,getRandomNumberUsingNextInt(0,99*1000));
                        sendToDatabase(nt);
                    }


                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            } );

        }
    }

    void getTargetId(String email,Messages msg){
        Query = userdatabase.child("users").orderByChild("email").equalTo(email);
        Query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NotNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot users : dataSnapshot.getChildren()) {
                        Users user = users.getValue(Users.class);
                        Log.d("TargetID",user.getUserID());
                        sendNotif(user.getUserID(),msg.getMessagID());
                    }
                } else {
                    Toast.makeText(Message.this, R.string.toast_user_notfound, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            Log.d("Message","Connection to database Failed ");
            }
        });
    }

    void sendNotif(String ID,String id){
        FirebaseDatabase.getInstance().getReference().child("Tokens").child(ID).child("token").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String usertoken=dataSnapshot.getValue(String.class);
                if(usertoken!=null)
                sendNotifications(usertoken,id);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        }

    public void sendNotifications(String usertoken,String id) {
        Data data = new Data(id);
        NotificationSender sender = new NotificationSender(data, usertoken);
        apiService.sendNotifcation(sender).enqueue(new Callback<MyResponse>() {
            @Override
            public void onResponse(Call<MyResponse> call, Response<MyResponse> response) {
                if (response.code() == 200) {
                    if (response.body().success != 1) {
                        Toast.makeText(Message.this, "Notification send Failed", Toast.LENGTH_LONG).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<MyResponse> call, Throwable t) {

            }
        });
    }

    void sendToDatabase(Notifications noti){
        FirebaseDatabase.getInstance().getReference("Notifications").child(noti.getMessageID()).setValue(noti);
    }

    void Uploadfile(Uri urim, String filename) {
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference href = storage.getReference();
        StorageReference ref = href.child("Files/" + filename);
        final String[] tmp = null;
        new Thread(new Runnable() {
            @Override
            public void run() {
                uploadTask = ref.putFile(urim);
                pass = false;
                Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                    @Override
                    public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                        if (!task.isSuccessful()) {
                            throw task.getException();
                        }
                        return ref.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        if (task.isSuccessful()) {
                            showNotification(getString(R.string.app_name), getString(R.string.notification_upload_complete), 0, 0, Message.this, true);
                            result = task.getResult().toString();
                            pass = true;
                        } else {
                            if (!(uploadTask.isCanceled()))
                                Toast.makeText(Message.this, R.string.toast_network_error, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                uploadTask.addOnProgressListener(o = new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                        long progress = ((taskSnapshot.getBytesTransferred() * 100) / taskSnapshot.getTotalByteCount());
                        if (!(uploadTask.isCanceled()))
                            showNotification(getString(R.string.app_name), getString(R.string.notification_upload), 100, (int) progress, Message.this, true);
                    }
                });
                uploadTask.addOnFailureListener(new OnFailureListener() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        //showNotification(R.string.notification_title, "annulé", 999, 999, Message.this, false);
                    }
                });
            }}).start();
    }
    public void OpenDeviceCamera(View view) {
        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            photoFile = createImageFile();
            UriSave = FileProvider.getUriForFile(Objects.requireNonNull(getApplicationContext()),
                    BuildConfig.APPLICATION_ID + ".provider", photoFile);
            takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, UriSave);
            startActivityForResult(takePhotoIntent, TAKE_PICTURE);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        imageFileName = "IMG_JPEG_" + timeStamp + "_";
        File storageDir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,
                ".jpg",
                storageDir
        );
        realPath= image.getAbsolutePath();
        return image;
    }
    public String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                }
            } finally {
                assert cursor != null;
                cursor.close();
            }
        }
        if (result == null) {
            result = uri.getPath();
            assert result != null;
            int cut = result.lastIndexOf('/');
            if (cut != -1) {
                result = result.substring(cut + 1);
            }
        }
        return result;
    }
    public void contact(){

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("users");
        Query query = databaseReference.orderByChild( "email" ).equalTo( to.getText().toString().trim() );
        new Thread(new Runnable() {
            @Override
            public void run() {
                query.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot d : dataSnapshot.getChildren()) {
                            Users users = d.getValue(Users.class);

                            DatabaseReference profilepicture = FirebaseDatabase.getInstance().getReference("ProfilePicture");
                            assert users != null;
                            Query query1 = profilepicture.child(users.getUserID());

                            query1.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    for (DataSnapshot i : dataSnapshot.getChildren()) {
                                        final UploadImages image = i.getValue(UploadImages.class);
                                        ;

                                        final DatabaseReference user = FirebaseDatabase.getInstance().getReference("users");
                                        assert image != null;
                                        Query query = user.orderByChild("email").equalTo(image.getUserEmail());
                                        query.addValueEventListener(new ValueEventListener() {

                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                                for (DataSnapshot u : dataSnapshot.getChildren()) {
                                                    Users user = u.getValue(Users.class);
                                                    assert user != null;
                                                    DatabaseReference Contacts = FirebaseDatabase.getInstance().getReference("Contacts").child(userID).child("contacts");
                                                    Contacts contact = new Contacts(image.getUserID(), image.getUserFullname(), image.getUserEmail(), image.getmImageUrl(), userID, user.getPhonenumber());
                                                    Contacts.child(image.getUserID()).setValue(contact);
                                                }

                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                            }
                                        });
                                    }

                                }
                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                }
                            });

                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }}).start();
    }
}
