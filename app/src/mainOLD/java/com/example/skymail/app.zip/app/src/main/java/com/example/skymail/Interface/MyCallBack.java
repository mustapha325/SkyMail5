package com.example.skymail.Interface;

public interface MyCallBack {
    void onCallback(String value);

}
